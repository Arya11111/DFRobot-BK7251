#ifndef __DRV_USBD_H__
#define __DRV_USBD_H__

int rt_usbd_init(void);
int cdc_echo(void);
#endif