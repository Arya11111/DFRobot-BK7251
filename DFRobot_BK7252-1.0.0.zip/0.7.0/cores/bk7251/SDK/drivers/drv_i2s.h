#ifndef __DRV_I2S_H__
#define __DRV_I2S_H__

#include "typedef.h"
#include "i2s.h"
#include "i2s_pub.h"
#include "gpio_pub.h"

int rt_i2s_hw_init(void);



#endif
