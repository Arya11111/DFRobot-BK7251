#ifndef __DRV_SDIO_SD_H__
#define __DRV_SDIO_SD_H__
int rt_hw_sdcard_init(void);
#endif
