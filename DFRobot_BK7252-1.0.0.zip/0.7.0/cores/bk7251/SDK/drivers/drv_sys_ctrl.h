#ifndef __DRV_SYS_CTRL_H__
#define __DRV_SYS_CTRL_H__

#include "sys_ctrl_pub.h"

int rt_hw_sys_ctrl_init(void);
int rt_hw_sys_ctrl_exit(void);

#endif

