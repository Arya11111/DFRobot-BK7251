#ifndef __DRV_GPIO_H__
#define __DRV_GPIO_H__

#include "gpio_pub.h"

int rt_hw_gpio_init(void);
int rt_hw_gpio_exit(void);

#endif