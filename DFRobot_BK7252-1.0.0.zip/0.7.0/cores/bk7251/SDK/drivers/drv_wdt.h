#ifndef __DRV_WDT_H__
#define __DRV_WDT_H__

#include "wdt_pub.h"

int rt_hw_wdt_init(void);
int rt_hw_wdt_exit(void);

#endif