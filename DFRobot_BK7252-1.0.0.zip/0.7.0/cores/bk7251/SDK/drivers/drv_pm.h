#ifndef __DRV_PM_H__
#define __DRV_PM_H__

int drv_pm_init(void)

#endif