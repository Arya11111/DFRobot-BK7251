/**
 **************************************************************************************
 * @file    psram.h
 * @brief   Driver API PSRAM
 *
 * @author  Aixing.Li
 * @version V1.0.0
 *
 * &copy; 2017 BEKEN Corporation Ltd. All rights reserved.
 **************************************************************************************
 */

#ifndef __PSRAM_H__
#define __PSRAM_H__


#endif//__PSRAM_H__
