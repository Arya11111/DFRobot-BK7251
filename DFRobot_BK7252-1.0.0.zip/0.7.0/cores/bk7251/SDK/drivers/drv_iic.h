#ifndef __DRV_IIC_H__
#define __DRV_IIC_H__

int iic_bus_attach(void);
int drv_iic2_init(void);
#endif