#ifndef __DRV_PWM_H__
#define __DRV_PWM_H__

#include "pwm_pub.h"

int rt_hw_pwm_init(void);
int rt_hw_pwm_exit(void);

#endif