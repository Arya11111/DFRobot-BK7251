#ifndef _TARGET_UTIL_PUB_H_
#define _TARGET_UTIL_PUB_H_

extern void delay_(INT32 num);
extern void delay2(int num);
extern void delay_ms(UINT32 ms_count);
extern void delay_sec(UINT32 ms_count);
extern void delay_tick(UINT32 tick_count);

#endif // _TARGET_UTIL_PUB_H_
