#ifndef _APP_MUSIC_PUB_H_
#define _APP_MUSIC_PUB_H_

extern void media_thread_init(void);
extern void media_msg_sender(void const *param_ptr);
extern void key_init(void);

#endif
