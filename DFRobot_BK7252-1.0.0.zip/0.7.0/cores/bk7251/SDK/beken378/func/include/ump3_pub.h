#ifndef _U_MP3_PUB_H_
#define _U_MP3_PUB_H_

extern void um_init(void);
extern void um_uninit(void);

#endif // _U_MP3_PUB_H_
// eof
