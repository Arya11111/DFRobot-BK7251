#ifndef _PSEUDO_RANDOM_PUB_H_
#define _PSEUDO_RANDOM_PUB_H_

extern uint32_t prandom_get(void);

#endif // _PSEUDO_RANDOM_PUB_H_
// eof 
