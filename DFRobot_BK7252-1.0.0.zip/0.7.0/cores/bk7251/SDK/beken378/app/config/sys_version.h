#ifndef _SYS_VERSION_H_
#define _SYS_VERSION_H_

#define RELEASE_VERSION              "1.0.7"
#define RELEASE_TIME                 "2018.07.27 13:44"
#define FMALL_VERSION                "5.0.4"
#define FMAC_LIB_VERSON              "2.0.2"

#endif // _SYS_VERSION_H_
