#ifndef __RTOS_H__
#define __RTOS_H__

#include <rtthread.h>
#include <rthw.h>

#endif

