#ifndef __TASK_H__
#define __TASK_H__

/**
 * 加入空头文件，使编译通过
 */ 

typedef void * TaskHandle_t;
#define xTaskHandle TaskHandle_t

#endif
