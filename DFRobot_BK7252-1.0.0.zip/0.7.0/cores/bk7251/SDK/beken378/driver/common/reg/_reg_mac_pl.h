#ifndef __REG_MAC_PL_H_
#define __REG_MAC_PL_H_

#define REG_MAC_PL_SIZE      1404
#define REG_MAC_PL_BASE_ADDR 0xC0008000

#endif // __REG_MAC_PL_H_

