#ifndef __REG_AGC_H_
#define __REG_AGC_H_

#define REG_AGC_SIZE 172

#define REG_AGC_BASE_ADDR 0x01000000


#endif // __REG_AGC_H_

