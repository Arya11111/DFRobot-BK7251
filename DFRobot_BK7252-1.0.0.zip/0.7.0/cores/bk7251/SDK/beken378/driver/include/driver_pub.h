#ifndef _DRIVER_PUB_H_
#define _DRIVER_PUB_H_

extern UINT32 driver_init(void);

#endif // _DRIVER_PUB_H_
// eof

