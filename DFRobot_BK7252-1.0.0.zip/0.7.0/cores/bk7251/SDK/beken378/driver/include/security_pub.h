#ifndef _SEC_PUB_H_
#define _SEC_PUB_H_

#define SEC_DEV_NAME		"sec"

void bk_secrity_init(void);
void bk_secrity_exit(void);

#endif
