/*
 * File: codec_opencore_amr.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __CODEC_OPENCORE_AMR_H__
#define __CODEC_OPENCORE_AMR_H__

int player_codec_opencore_amr_register(void);

#endif
