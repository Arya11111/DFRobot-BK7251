/*
 * File: format_m4a.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __FORMAT_M4A_H__
#define __FORMAT_M4A_H__

int player_codec_beken_aac_register(void);
int player_codec_beken_m4a_register(void);

#endif /* STREAM_H */
