/*
 * File: codec_helixmp3.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __CODEC_HELIXMP3_H__
#define __CODEC_HELIXMP3_H__

int player_codec_helixmp3_register(void); 

#endif
