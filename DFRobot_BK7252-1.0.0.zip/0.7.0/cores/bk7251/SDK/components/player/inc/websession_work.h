/*
 * File: websession_work.h 
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __WEBSESSION_WORK_H__
#define __WEBSESSION_WORK_H__

void websession_work(struct rt_work* work, void* user_data);

#endif
