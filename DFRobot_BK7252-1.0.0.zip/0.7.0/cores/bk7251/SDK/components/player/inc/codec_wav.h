/*
 * File: codec_wav.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __CODEC_WAV_H__
#define __CODEC_WAV_H__

int player_codec_wav_register(void); 

#endif
