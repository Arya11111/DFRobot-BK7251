/*
 * File: player_init.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __PLAYER_INIT_H__
#define __PLAYER_INIT_H__

int player_system_init(void); 

#endif