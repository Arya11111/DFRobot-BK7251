/*
 * File: hls_work.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __HLS_WORK_H__ 
#define __HLS_WORK_H__ 

void hls_work(struct rt_work* work, void* user_data);

#endif 

