/*
 * File: format_ts.h
 * 
 * COPYRIGHT (C) 2012-2018, Shanghai Real-Thread Technology Co., Ltd
 */

#ifndef __FORMAT_TS_H__
#define __FORMAT_TS_H__

int player_format_ts_register(void);

#endif /* __FORMAT_TS_H__ */
